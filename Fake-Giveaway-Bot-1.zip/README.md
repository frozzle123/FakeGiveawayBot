# Fake Giveaway Bot
**This bot is for people who have reward servers and want to fake giveaways.**
*fbdh on discord for help*

# Installation
- `npm i`
- `put ur token in index.js`
- `node index.js`