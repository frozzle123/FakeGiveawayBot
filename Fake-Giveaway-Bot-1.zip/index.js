const { Client, Intents, MessageActionRow, MessageButton } = require('discord.js');
const ms = require('ms');
const db = require('quick.db');
require('dotenv').config(); // Ensure you are using dotenv to load the token

const client = new Client({
    intents: [
        Intents.FLAGS.GUILDS,
        Intents.FLAGS.GUILD_MESSAGES,
        Intents.FLAGS.GUILD_MEMBERS, // Ensure you have this intent to fetch members
    ],
});

const prefix = ".";
let count = 0;

client.once("ready", () => {
    console.log(`Ready As: ${client.user.id}`);
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isButton()) return;

    const giveaway = db.get(`giveaway_${interaction.message.id}`);
    if (!giveaway) {
        return interaction.reply({
            content: 'Giveaway not found.',
            ephemeral: true
        });
    }

    if (giveaway.enteredUsers.includes(interaction.user.id)) {
        return interaction.reply({
            content: 'You have already entered this giveaway!',
            ephemeral: true
        });
    }

    await interaction.deferUpdate();

    giveaway.enteredUsers.push(interaction.user.id);
    db.set(`giveaway_${interaction.message.id}`, giveaway);

    count = giveaway.enteredUsers.length;

    let startGiveawayEmbed = {
        title: giveaway.prize,
        description: `Ends in: <t:${Math.floor(giveaway.endTime / 1000)}:R> (<t:${Math.floor(giveaway.endTime / 1000)}:f>)\nHosted By: **${giveaway.hostedBy}**\nEntries: **${count}**\nWinners: **${giveaway.winnerCount}**`,
        color: '#5865f2',
        timestamp: giveaway.endTime,
    };

    await interaction.message.edit({
        embeds: [startGiveawayEmbed]
    });
});

client.on('messageCreate', async (message) => {
    if (message.content.startsWith(prefix + "gstart")) {
        const args = message.content.slice(prefix.length).trim().split(/ +/);

        if (args.length < 5) {
            return message.channel.send('Usage: `.gstart <duration> <winner_count> <#channel> <@role1> <@role2> ... <prize>`\nExample: `.gstart 10s 2 #giveaway @role1 @role2 Free Nitro`');
        }

        let duration = args[1];
        let winnerCount = parseInt(args[2], 10);
        let giveawayChannel = message.mentions.channels.first();
        let winnerRoles = message.mentions.roles;
        let prize = args.slice(winnerRoles.size + 3).join(" ");

        if (!ms(duration)) {
            return message.channel.send('Invalid duration format. Use `d`, `h`, `m`, or `s`. Example formats: `10m`, `2h`, `1d`.');
        }

        if (isNaN(winnerCount) || winnerCount < 1) {
            return message.channel.send('Please provide a valid number of winners (positive integer).');
        }

        if (!giveawayChannel) {
            return message.channel.send("Please mention a valid channel to start the giveaway!");
        }

        if (winnerRoles.size < winnerCount) {
            return message.channel.send('Not enough roles provided. Please mention enough roles for the winners.');
        }

        if (!prize) {
            return message.channel.send('Please provide a prize for the giveaway!');
        }

        count = 0;
        const endTime = Date.now() + ms(duration);

        let startGiveawayEmbed = {
            title: prize,
            description: `Ends in: <t:${Math.floor(endTime / 1000)}:R> (<t:${Math.floor(endTime / 1000)}:f>)\nHosted By: **${message.author.username}**\nEntries: **0**\nWinners: **${winnerCount}**`,
            color: '#5865f2',
            timestamp: endTime,
        };

        const row = new MessageActionRow()
            .addComponents(
                new MessageButton()
                    .setCustomId(`giveaway_${message.id}`) // Unique giveaway ID
                    .setLabel('🎉')
                    .setStyle('PRIMARY')
            );

        try {
            const embedGiveawayHandle = await giveawayChannel.send({
                embeds: [startGiveawayEmbed],
                components: [row]
            });

            db.set(`giveaway_${embedGiveawayHandle.id}`, {
                prize,
                endTime,
                hostedBy: message.author.username,
                winnerCount,
                enteredUsers: [],
                winnerRoles: winnerRoles.map(role => role.id),
            });

            setTimeout(async () => {
                const giveaway = db.get(`giveaway_${embedGiveawayHandle.id}`);
                if (!giveaway) return;

                // Fetch the guild from the channel
                const guild = giveawayChannel.guild;

                // Get the list of roles
                const roleWinners = giveaway.winnerRoles.map(roleId => {
                    const role = guild.roles.cache.get(roleId);
                    return role ? `<@&${roleId}>` : null;
                }).filter(roleMention => roleMention !== null);

                const endedEmbedGiveaway = {
                    title: `Giveaway Ended: ${prize}`,
                    description: `Ended: <t:${Math.floor(endTime / 1000)}:R> (<t:${Math.floor(endTime / 1000)}:f>)\nHosted By: **${message.author.username}**\nEntries: **${giveaway.enteredUsers.length}**\nWinners: **${giveaway.winnerCount}**`,
                    color: '#2f3136',
                    timestamp: Date.now(),
                    footer: { text: "Giveaway ended" },
                };

                const roww = new MessageActionRow()
                    .addComponents(
                        new MessageButton()
                            .setStyle('LINK')
                            .setLabel('Giveaway Summary')
                            .setURL('https://discord.com/channels/1147191408176935013/1147191408734781512')
                    );

                try {
                    await embedGiveawayHandle.edit({
                        embeds: [endedEmbedGiveaway],
                        components: [roww]
                    });

                    if (roleWinners.length > 0) {
                        giveawayChannel.send(`🥳 Congratulations ${roleWinners.join(', ')}! You won **${prize}**!`);
                    } else {
                        giveawayChannel.send(`🥳 No role-matched winners found. Congratulations to the winners! You won **${prize}**!`);
                    }

                    db.delete(`giveaway_${embedGiveawayHandle.id}`);
                } catch (error) {
                    console.error('Error ending the giveaway:', error);
                    giveawayChannel.send('An error occurred while ending the giveaway.');
                }
            }, ms(duration));

        } catch (error) {
            console.error('Error sending giveaway message:', error);
            return message.channel.send('An error occurred while starting the giveaway.');
        }
    }
});

process.on('multipleResolves', (type, promise, reason) => {
    console.log('[antiCrash] :: [multipleResolves]');
    console.log(type, promise, reason);
});
process.on('unhandledRejection', (reason, promise) => {
    console.log('[antiCrash] :: [unhandledRejection]');
    console.log(promise, reason);
});
process.on("uncaughtException", (err, origin) => {
    console.log('[antiCrash] :: [uncaughtException]');
    console.log(err, origin);
});
process.on('uncaughtExceptionMonitor', (err, origin) => {
    console.log('[antiCrash] :: [uncaughtExceptionMonitor]');
    console.log(err, origin);
});

// Ensure the token is loaded and the bot is logging in correctly
console.log("Bot Token: ", process.env.TOKEN);
client.login(process.env.TOKEN);
